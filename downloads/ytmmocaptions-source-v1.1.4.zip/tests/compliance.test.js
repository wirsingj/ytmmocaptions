const fs = require("node:fs");
const path = require("node:path");

const ROOT_DIR = path.resolve(__dirname, "..");

function readJson(relativePath) {
  return JSON.parse(fs.readFileSync(path.join(ROOT_DIR, relativePath), "utf8"));
}

function runtimePathExists(manifestName, runtimePath) {
  if (manifestName === "manifest.json") {
    return fs.existsSync(path.join(ROOT_DIR, runtimePath));
  }
  const sourcePath = runtimePath.replace(/^scripts\//, "src/");
  return fs.existsSync(path.join(ROOT_DIR, sourcePath));
}

exports.run = async function runComplianceTests(ctx) {
  const { assert, runCase } = ctx;
  const manifests = ["manifest.json", "manifest.chrome.json", "manifest.firefox.json"];

  await runCase("all manifests request storage permission only", () => {
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      assert.deepEqual(manifest.permissions, ["storage"], fileName);
    }
  });

  await runCase("release manifests stay YouTube-only and avoid broad site access", () => {
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      assert.equal(manifest.name, "YTMMOCC", fileName);
      assert.deepEqual(manifest.host_permissions, ["https://www.youtube.com/*"], fileName);
      assert.deepEqual(manifest.content_scripts[0].matches, ["https://www.youtube.com/*"], fileName);
      assert.equal(Object.prototype.hasOwnProperty.call(manifest, "optional_permissions"), false, fileName);
      assert.equal(Object.prototype.hasOwnProperty.call(manifest, "background"), false, fileName);
      assert.equal(Object.prototype.hasOwnProperty.call(manifest, "externally_connectable"), false, fileName);
      assert.ok(!manifest.permissions.includes("tabs"), fileName);
      assert.ok(!manifest.permissions.includes("activeTab"), fileName);
      assert.ok(!manifest.permissions.includes("scripting"), fileName);
      const serialized = JSON.stringify(manifest);
      assert.ok(!serialized.includes("<all_urls>"), fileName);
      assert.ok(!serialized.includes("*://*/*"), fileName);
      assert.ok(!serialized.includes("http://*/*"), fileName);
      assert.ok(!serialized.includes("https://*/*"), fileName);
      for (const block of manifest.web_accessible_resources || []) {
        assert.deepEqual(block.matches, ["https://www.youtube.com/*"], fileName);
      }
    }
    const contentScript = fs.readFileSync(path.join(ROOT_DIR, "src", "content-script.js"), "utf8");
    assert.ok(contentScript.includes("transcript.isWatchPage(url)"));
    assert.ok(contentScript.includes("transcript.getVideoId(url)"));
    assert.ok(!contentScript.includes("startGenericRegistryIfAllowed"));
    assert.ok(!contentScript.includes("universalCaptions"));
  });

  await runCase("content script order loads bubble-state before content-script", () => {
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      const js = manifest.content_scripts[0].js;
      const platformIndex = js.findIndex((item) => item.includes("platform.js"));
      const diagnosticsIndex = js.findIndex((item) => item.includes("diagnostics.js"));
      const pageContextIndex = js.findIndex((item) => item.includes("page-context.js"));
      const captionTextIndex = js.findIndex((item) => item.includes("caption-text.js"));
      const bubbleIndex = js.findIndex((item) => item.includes("bubble-state.js"));
      const scrubIndex = js.findIndex((item) => item.includes("timeline-scrub.js"));
      const transcriptIndex = js.findIndex((item) => item.includes("transcript.js"));
      const timelineIndex = js.findIndex((item) => item.includes("caption-timeline.js"));
      const universalIndex = js.findIndex((item) => item.includes("universal-captions.js"));
      const contentIndex = js.findIndex((item) => item.includes("content-script.js"));
      assert.ok(platformIndex >= 0, fileName + " missing platform.js");
      assert.ok(diagnosticsIndex >= 0, fileName + " missing diagnostics.js");
      assert.ok(pageContextIndex >= 0, fileName + " missing page-context.js");
      assert.ok(captionTextIndex >= 0, fileName + " missing caption-text.js");
      assert.ok(bubbleIndex >= 0, fileName + " missing bubble-state.js");
      assert.ok(scrubIndex >= 0, fileName + " missing timeline-scrub.js");
      assert.ok(transcriptIndex >= 0, fileName + " missing transcript.js");
      assert.ok(timelineIndex >= 0, fileName + " missing caption-timeline.js");
      assert.ok(contentIndex >= 0, fileName + " missing content-script.js");
      assert.ok(platformIndex < diagnosticsIndex, fileName + " loads platform before diagnostics");
      assert.ok(diagnosticsIndex < pageContextIndex, fileName + " loads diagnostics before page-context");
      assert.ok(captionTextIndex < contentIndex, fileName + " loads content-script before caption-text");
      assert.ok(bubbleIndex < contentIndex, fileName + " loads content-script too early");
      assert.ok(bubbleIndex < scrubIndex, fileName + " loads timeline scrub before bubble-state");
      assert.ok(scrubIndex < contentIndex, fileName + " loads content-script before timeline scrub");
      assert.ok(transcriptIndex < timelineIndex, fileName + " loads caption timeline before transcript");
      assert.ok(timelineIndex < contentIndex, fileName + " loads content-script before caption timeline");
      assert.equal(universalIndex, -1, fileName + " should not load generic-video experiment in release manifest");
    }
  });

  await runCase("manifest runtime JS/CSS paths exist in source or build context", () => {
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      for (const script of manifest.content_scripts[0].js) {
        assert.ok(runtimePathExists(fileName, script), fileName + " missing " + script);
      }
      for (const css of manifest.content_scripts[0].css) {
        assert.ok(runtimePathExists(fileName, css), fileName + " missing " + css);
      }
      for (const block of manifest.web_accessible_resources || []) {
        for (const resource of block.resources || []) {
          assert.ok(runtimePathExists(fileName, resource), fileName + " missing " + resource);
        }
      }
      for (const iconPath of Object.values(manifest.icons || {})) {
        assert.ok(runtimePathExists(fileName, iconPath), fileName + " missing icon " + iconPath);
      }
    }
  });

  await runCase("v1 release manifests include marketplace icons", () => {
    const packageJson = readJson("package.json");
    assert.match(packageJson.version, /^\d+\.\d+\.\d+$/);
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      assert.equal(manifest.version, packageJson.version, fileName);
      assert.deepEqual(Object.keys(manifest.icons || {}).sort(), ["128", "48", "96"], fileName);
      for (const iconPath of Object.values(manifest.icons)) {
        assert.ok(iconPath.startsWith("assets/icons/"), fileName);
        assert.ok(fs.existsSync(path.join(ROOT_DIR, iconPath)), iconPath);
      }
    }
  });

  await runCase("marketplace listing assets exist but are not packaged as runtime files", () => {
    assert.ok(fs.existsSync(path.join(ROOT_DIR, "store-assets", "amo-listing-draft.md")));
    assert.ok(fs.existsSync(path.join(ROOT_DIR, "store-assets", "screenshot-panel-over-video.png")));
    for (const dirName of ["build/chrome", "build/firefox"]) {
      const buildPath = path.join(ROOT_DIR, dirName);
      if (!fs.existsSync(buildPath)) {
        continue;
      }
      assert.equal(fs.existsSync(path.join(buildPath, "store-assets")), false, dirName);
      assert.ok(fs.existsSync(path.join(buildPath, "assets", "icons", "icon-128.png")), dirName);
    }
  });

  await runCase("Firefox manifest declares no data collection and non-placeholder ID", () => {
    const manifest = readJson("manifest.firefox.json");
    assert.deepEqual(
      manifest.browser_specific_settings.gecko.data_collection_permissions.required,
      ["none"]
    );
    const id = manifest.browser_specific_settings.gecko.id;
    assert.notEqual(id, "dialogue-captions@example.local");
    assert.ok(/@/.test(id), "Firefox extension ID should be stable");
    assert.equal(manifest.browser_specific_settings.gecko.strict_min_version, "142.0");
    assert.equal(Object.prototype.hasOwnProperty.call(manifest.browser_specific_settings, "gecko_android"), false);
  });

  await runCase("package build script does not bump versions", () => {
    const packageJson = readJson("package.json");
    assert.equal(packageJson.scripts.build, "node scripts/build.mjs");
    assert.equal(packageJson.scripts["diagnostic:e2e"], "node tests/e2e-extension-debug.js");
    assert.ok(packageJson.scripts["release:sanity"].includes("verify-release-artifacts.ps1"));
    assert.ok(packageJson.scripts["verify:release-version"].includes("verify-release-version.mjs"));
    assert.ok(packageJson.scripts["package:source"].includes("package-source.ps1"));
    assert.ok(!packageJson.scripts["release:check"].includes("version:bump"));
    assert.ok(!packageJson.scripts["release:check"].includes("bump-version"));
    assert.ok(!packageJson.scripts["release:sanity"].includes("version:bump"));
    assert.ok(!packageJson.scripts["release:sanity"].includes("bump-version"));
    const bumpVersion = fs.readFileSync(path.join(ROOT_DIR, "scripts", "bump-version.mjs"), "utf8");
    assert.ok(bumpVersion.includes('"package-lock.json"'));
    assert.ok(bumpVersion.includes('json.packages[""].version = nextVersion'));
  });

  await runCase("test runner auto-discovers every test file", () => {
    const runner = fs.readFileSync(path.join(ROOT_DIR, "tests", "run-tests.js"), "utf8");
    const testFiles = fs.readdirSync(path.join(ROOT_DIR, "tests")).filter((fileName) => fileName.endsWith(".test.js"));
    assert.ok(runner.includes(".filter((fileName) => fileName.endsWith(\".test.js\"))"));
    for (const fileName of testFiles) {
      assert.ok(runner.includes(fileName) || runner.includes("discovered"), "runner may omit " + fileName);
    }
  });

  await runCase("content script does not inject page bridge at module startup", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "content-script.js"), "utf8");
    const startupRegion = source.slice(0, source.indexOf("class DialogueCaptionsApp"));
    assert.ok(!startupRegion.includes("ensureBridgeInjected()"));
    assert.ok(source.includes("ensurePageBridgeForWatchPage()"));
  });

  await runCase("page bridge omits XSRF_TOKEN and narrows fetch host checks", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "page-bridge.js"), "utf8");
    assert.ok(!source.includes('"XSRF_TOKEN"'));
    assert.ok(source.includes('host !== "www.youtube.com"'));
    assert.ok(source.includes('path === "/api/timedtext"'));
    assert.ok(source.includes('path === "/youtubei/v1/get_transcript"'));
    assert.ok(source.includes('path === "/youtubei/v1/get_panel"'));
  });

  await runCase("transcript fetch fallback uses the same YouTube allowlist", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "transcript.js"), "utf8");
    assert.ok(source.includes('parsed.hostname !== "www.youtube.com"'));
    assert.ok(source.includes('path === "/api/timedtext"'));
    assert.ok(source.includes('path === "/youtubei/v1/get_transcript"'));
    assert.ok(source.includes('path === "/youtubei/v1/get_panel"'));
    assert.ok(source.includes('error: "blocked_request"'));
  });

  await runCase("global keyboard is pointer-over-panel only", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "content-script.js"), "utf8");
    assert.ok(source.includes("return this.panel.isPointerInside();"));
    assert.ok(!source.includes("globalKeyboardEnabled"));
  });

  await runCase("build output manifests keep storage permission when present", () => {
    for (const dirName of ["build/chrome", "build/firefox"]) {
      const manifestPath = path.join(ROOT_DIR, dirName, "manifest.json");
      if (!fs.existsSync(manifestPath)) {
        continue;
      }
      const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
      assert.deepEqual(manifest.permissions, ["storage"], dirName);
    }
  });

  await runCase("release hygiene ignores signing keys and documents current downloads only", () => {
    const gitignore = fs.readFileSync(path.join(ROOT_DIR, ".gitignore"), "utf8");
    const readme = fs.readFileSync(path.join(ROOT_DIR, "README.md"), "utf8");
    assert.ok(gitignore.includes("*.pem"), "private signing keys must stay ignored");
    assert.ok(gitignore.includes("downloads/*/"), "extracted local packages should stay ignored");
    assert.ok(!readme.includes("dialogue-captions-friend-v0.25.61.zip"));
  });

  await runCase("package scripts reject Windows-style archive paths", () => {
    for (const fileName of ["package-chrome.ps1", "package-firefox.ps1", "package-source.ps1"]) {
      const source = fs.readFileSync(path.join(ROOT_DIR, "scripts", fileName), "utf8");
      assert.ok(source.includes("hasBackslashEntries"), fileName);
      assert.ok(source.includes("Windows-style backslash archive paths"), fileName);
    }
    const sourcePackage = fs.readFileSync(path.join(ROOT_DIR, "scripts", "package-source.ps1"), "utf8");
    assert.ok(sourcePackage.includes('StartsWith("artifacts/"'), "source package must exclude local test artifacts");
    assert.ok(sourcePackage.includes("Sort-Object -Property FullName"), "source package entries should be deterministic");
    assert.ok(sourcePackage.includes("entry.LastWriteTime"), "source package timestamps should be deterministic");
  });

  await runCase("release automation uses numbered workflows and approval-gated store publishing", () => {
    const ci = fs.readFileSync(path.join(ROOT_DIR, ".github", "workflows", "ci.yml"), "utf8");
    const prepareRelease = fs.readFileSync(path.join(ROOT_DIR, ".github", "workflows", "1-prepare-release.yml"), "utf8");
    const releaseFirefox = fs.readFileSync(path.join(ROOT_DIR, ".github", "workflows", "2-release-firefox.yml"), "utf8");
    const releaseChrome = fs.readFileSync(path.join(ROOT_DIR, ".github", "workflows", "3-release-chrome.yml"), "utf8");
    const releaseDocs = fs.readFileSync(path.join(ROOT_DIR, "RELEASE.md"), "utf8");
    assert.ok(ci.includes("pull_request:"));
    assert.ok(ci.includes("npm run release:sanity"));
    assert.ok(!ci.includes("store-publish"));
    assert.ok(!ci.includes("CHROME_CLIENT_SECRET"));
    assert.ok(prepareRelease.includes("name: 1) Prepare Release"));
    assert.ok(prepareRelease.includes("workflow_dispatch:"));
    assert.ok(prepareRelease.includes("ref: main"));
    assert.ok(prepareRelease.includes("npm run version:bump"));
    assert.ok(prepareRelease.includes("npm run release:sanity"));
    assert.ok(prepareRelease.includes("node scripts/verify-release-version.mjs"));
    assert.ok(prepareRelease.includes("git commit -m \"chore: prepare"));
    assert.ok(prepareRelease.includes("git tag -a"));
    assert.ok(prepareRelease.includes("git push origin HEAD:main"));
    assert.ok(prepareRelease.includes("gh release create"));
    assert.ok(!prepareRelease.includes("environment: store-publish"));
    assert.ok(!prepareRelease.includes("CHROME_CLIENT_SECRET"));
    assert.ok(releaseChrome.includes("name: 3) Release Chrome"));
    assert.ok(releaseChrome.includes("workflow_dispatch:"));
    assert.ok(!releaseChrome.includes("chrome_action:"));
    assert.ok(releaseChrome.includes("environment: store-publish"));
    assert.ok(releaseChrome.includes("scripts/verify-release-version.mjs"));
    assert.ok(releaseChrome.includes("git merge-base --is-ancestor"));
    assert.ok(releaseChrome.includes("CHROME_PUBLISHER_ID"));
    assert.ok(releaseChrome.includes("CHROME_EXTENSION_ID"));
    assert.ok(releaseChrome.includes("CHROME_CLIENT_SECRET"));
    assert.ok(releaseChrome.includes("is configured."));
    assert.ok(releaseChrome.includes("Missing Chrome Web Store secrets"));
    assert.ok(releaseChrome.includes('--mode="publish"'));
    assert.ok(releaseFirefox.includes("name: 2) Release Firefox"));
    assert.ok(releaseFirefox.includes("workflow_dispatch:"));
    assert.ok(releaseFirefox.includes("environment: store-publish"));
    assert.ok(releaseFirefox.includes("scripts/verify-release-version.mjs"));
    assert.ok(releaseFirefox.includes("git merge-base --is-ancestor"));
    assert.ok(releaseFirefox.includes("AMO_JWT_ISSUER"));
    assert.ok(releaseFirefox.includes("AMO_JWT_SECRET"));
    assert.ok(releaseFirefox.includes("is configured."));
    assert.ok(releaseFirefox.includes("Missing Firefox AMO secrets"));
    assert.ok(releaseDocs.includes("1) Prepare Release"));
    assert.ok(releaseDocs.includes("2) Release Firefox"));
    assert.ok(releaseDocs.includes("3) Release Chrome"));
    assert.ok(releaseDocs.includes("Repository secrets: `https://github.com/wirsingj/ytmmocaptions/settings/secrets/actions`"));
    assert.ok(releaseDocs.includes("AMO API keys: `https://addons.mozilla.org/en-US/developers/addon/api/key/`"));
    assert.ok(releaseDocs.includes("cocgdaogbkknnhdpmojlmodalmblndgf"));
    assert.ok(releaseDocs.includes("ad6905b1-f715-47f7-8140-25592b8fbca4"));
    assert.ok(releaseDocs.includes("https://www.googleapis.com/auth/chromewebstore"));
    assert.ok(releaseDocs.includes("Recovery If One Store Succeeds And The Other Fails"));
  });

  await runCase("store publish scripts avoid secret logging and default to safe upload mode", () => {
    const chrome = fs.readFileSync(path.join(ROOT_DIR, "scripts", "publish-chrome.mjs"), "utf8");
    const firefox = fs.readFileSync(path.join(ROOT_DIR, "scripts", "publish-firefox.ps1"), "utf8");
    assert.ok(chrome.includes('process.env.STORE_PUBLISH_MODE || "upload"'));
    assert.ok(chrome.includes("CHROME_PUBLISHER_ID"));
    assert.ok(chrome.includes("https://oauth2.googleapis.com/token"));
    assert.ok(chrome.includes("chromewebstore.googleapis.com/upload/v2/"));
    assert.ok(chrome.includes("chromewebstore.googleapis.com/v2/"));
    assert.ok(chrome.includes(":fetchStatus"));
    assert.ok(chrome.includes("waitForUploadReady"));
    assert.ok(!chrome.includes("console.log(accessToken"));
    assert.ok(!chrome.includes("CHROME_CLIENT_SECRET\";"));
    assert.ok(firefox.includes('if ($Mode -eq "upload")'));
    assert.ok(firefox.includes("web-ext lint"));
    assert.ok(firefox.includes("web-ext"));
    assert.ok(firefox.includes("sign"));
    assert.ok(firefox.includes("--upload-source-code"));
    assert.ok(!firefox.includes("--id"));
    assert.ok(firefox.includes("AMO_JWT_SECRET"));
  });

  await runCase("runtime does not use page localStorage for settings or debug state", () => {
    for (const fileName of ["settings-store.js", "transcript.js", "content-script.js", "diagnostics.js"]) {
      const source = fs.readFileSync(path.join(ROOT_DIR, "src", fileName), "utf8");
      assert.ok(!source.includes("localStorage"), fileName + " should use extension storage only");
      assert.ok(!source.includes("sessionStorage"), fileName + " should not use page session storage");
    }
  });

  await runCase("diagnostics are local-only, opt-in, and redact sensitive detail", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "diagnostics.js"), "utf8");
    const readme = fs.readFileSync(path.join(ROOT_DIR, "README.md"), "utf8");
    const privacy = fs.readFileSync(path.join(ROOT_DIR, "PRIVACY.md"), "utf8");
    assert.ok(source.includes('searchParams.get("dcdebug") === "1"'));
    assert.ok(source.includes("if (!isDebugEnabled())"));
    assert.ok(source.includes("/text|caption|transcript|body|token|cookie|title|url/i"));
    assert.ok(!source.includes("fetch("));
    assert.ok(readme.includes("window.DialogueCaptions.diagnostics.getReport()"));
    assert.ok(privacy.includes("Local Diagnostics"));
  });

  await runCase("source submission docs do not pin stale package versions", () => {
    const sourceSubmission = fs.readFileSync(path.join(ROOT_DIR, "SOURCE_SUBMISSION.md"), "utf8");
    assert.ok(sourceSubmission.includes("ytmmocaptions-firefox-v<package-version>.xpi"));
    assert.ok(!/v1\\.0\\.2/.test(sourceSubmission));
  });

  await runCase("optional e2e diagnostic is explicit, local, and avoids raw transcript assertions", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "tests", "e2e-extension-debug.js"), "utf8");
    const readme = fs.readFileSync(path.join(ROOT_DIR, "README.md"), "utf8");
    const gitignore = fs.readFileSync(path.join(ROOT_DIR, ".gitignore"), "utf8");
    assert.ok(source.includes("--browser must be chrome, firefox, or both."));
    assert.ok(source.includes("e2e-report.json"));
    assert.ok(source.includes("shared-source-injected-diagnostic"));
    assert.ok(source.includes("textLength"));
    assert.ok(source.includes("scorePercent"));
    assert.ok(!source.includes("document.title"));
    assert.ok(!source.includes("dQw4w9WgXcQ"));
    assert.ok(readme.includes("npm run diagnostic:e2e -- --browser=both --url=https://www.youtube.com/watch?v=VIDEO_ID --headed"));
    assert.ok(readme.includes("tests/artifacts/e2e-report.json"));
    assert.ok(gitignore.includes("tests/artifacts/"));
  });

  await runCase("panel cleans temporary pointer listeners during route teardown", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    assert.ok(panelSource.includes("activePointerCleanupFns"));
    assert.ok(panelSource.includes("cleanupActivePointerListeners()"));
    assert.ok(panelSource.includes("trackActivePointerListeners"));
    assert.ok(panelSource.includes('window.addEventListener("pointercancel"'));
    assert.ok(panelSource.includes('window.removeEventListener("pointercancel"'));
    assert.ok(panelSource.includes("this.dragState = null;"));
    assert.ok(panelSource.includes("this.resizeState = null;"));
    assert.ok(panelSource.includes("this.futureDividerDragState = null;"));
    assert.ok(panelSource.includes("this.launcherDragState = null;"));
  });

  await runCase("panel exposes natural edge and corner resize handles", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes('"top", "right", "bottom", "left"'));
    assert.ok(panelSource.includes("data-resize-zone"));
    assert.ok(panelSource.includes("isResizeZone(zone)"));
    assert.ok(panelSource.includes("resizesRight"));
    assert.ok(panelSource.includes("resizesBottom"));
    assert.ok(css.includes(".dc-resize-top,"));
    assert.ok(css.includes(".dc-resize-left,"));
    assert.ok(css.includes("cursor: ew-resize"));
    assert.ok(css.includes("cursor: ns-resize"));
  });

  await runCase("panel rejects cramped top-left locked layout snapshots", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    assert.ok(panelSource.includes("MIN_RESTORED_PANEL_WIDTH"));
    assert.ok(panelSource.includes("MIN_RESTORED_PANEL_HEIGHT"));
    assert.ok(panelSource.includes("MIN_DEFAULT_PANEL_WIDTH = 650"));
    assert.ok(panelSource.includes("DEFAULT_PANEL_WIDTH_RATIO = 0.52"));
    assert.ok(panelSource.includes("maxFrameWidth"));
    assert.ok(panelSource.includes("isRestorablePanelLayout"));
    assert.ok(panelSource.includes("cramped && pinnedTopLeft"));
    assert.ok(panelSource.includes("!this.isRestorablePanelLayout(rect, rect)"));
  });

  await runCase("panel header sliders shrink before controls wrap", () => {
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(css.includes("flex-wrap: nowrap;"));
    assert.ok(/\.dc-opacity-wrap,\s*\.dc-text-scale-wrap\s*\{/.test(css));
    assert.ok(css.includes("flex: 1 1 68px;"));
    assert.ok(css.includes("min-width: 0;"));
    assert.ok(css.includes("flex: 1 1 28px;"));
    assert.ok(css.includes("min-width: 16px;"));
    assert.ok(css.includes(".dc-control-actions"));
    assert.ok(css.includes("flex: 0 0 auto;"));
  });

  await runCase("future preview UI uses a movable divider and visually ghosted rows", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes("dc-future-divider"));
    assert.ok(panelSource.includes("dc-future-section"));
    assert.ok(panelSource.includes("futurePreviewEnabled"));
    assert.ok(panelSource.includes("dc-future-toggle-input"));
    assert.ok(panelSource.includes("shouldPreservePanelPlacement"));
    assert.ok(panelSource.includes("preservePanelPlacement: this.shouldPreservePanelPlacement(patch)"));
    assert.ok(panelSource.includes("!preservePanelPlacement"));
    assert.ok(panelSource.includes("handleFutureDividerPointerDown"));
    assert.ok(panelSource.includes("futureDividerDragState"));
    assert.ok(panelSource.includes("dc-chunk-future"));
    assert.ok(panelSource.includes("previousScrollTop"));
    assert.ok(panelSource.includes("nextList.scrollTop"));
    assert.ok(panelSource.includes("FUTURE_RENDER_BATCH = 80"));
    assert.ok(panelSource.includes("buildFutureChunksKey(chunks)"));
    assert.ok(panelSource.includes("getFutureRenderCount()"));
    assert.ok(panelSource.includes("handleFutureListScroll(futureList)"));
    assert.ok(panelSource.includes('role", "separator"'));
    assert.ok(!panelSource.includes('divider.textContent = "Next up"'));
    assert.ok(!panelSource.includes('divider.addEventListener("click"'));
    assert.ok(!panelSource.includes("dc-chunk-seek-icon"));
    assert.ok(css.includes(".dc-chunk-future"));
    assert.ok(!css.includes(".dc-chunk-seek-icon"));
    assert.ok(css.includes(".dc-future-divider"));
    assert.ok(css.includes(".dc-future-section"));
    assert.ok(css.includes("justify-content: flex-end"));
    assert.ok(css.includes("height: var(--dc-future-preview-height"));
    assert.ok(css.includes("display: block;"));
    assert.ok(css.includes("grid-template-columns: auto minmax(0, 1fr)"));
    assert.ok(css.includes("border-style: solid"));
    assert.ok(css.includes("text-overflow: ellipsis"));
    assert.ok(css.includes("white-space: nowrap"));
    assert.ok(css.includes("cursor: ns-resize"));
    assert.ok(css.includes("touch-action: none"));
  });

  await runCase("future preview rendering stays lazy for long transcript timelines", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const renderKeyStart = panelSource.indexOf("    getFutureRenderKey()");
    const renderKeyEnd = panelSource.indexOf("    createFutureSection", renderKeyStart);
    const sectionStart = panelSource.indexOf("    createFutureSection(futureRenderCount, chunkCount)");
    const sectionEnd = panelSource.indexOf("    replaceFutureSection(futureRenderCount, chunkCount)", sectionStart);
    assert.ok(renderKeyStart >= 0);
    assert.ok(renderKeyEnd > renderKeyStart);
    assert.ok(sectionStart >= 0);
    assert.ok(sectionEnd > sectionStart);
    const renderKeyBody = panelSource.slice(renderKeyStart, renderKeyEnd);
    const sectionBody = panelSource.slice(sectionStart, sectionEnd);
    assert.ok(renderKeyBody.includes("this.futureChunksKey"));
    assert.ok(renderKeyBody.includes("this.getFutureRenderCount()"));
    assert.ok(!renderKeyBody.includes("this.getChunkDisplayText(chunk)"));
    assert.ok(sectionBody.includes("index < futureRenderCount"));
    assert.ok(sectionBody.includes("handleFutureListScroll"));
    assert.ok(!sectionBody.includes("index < futureCount"));
  });

  await runCase("history rendering keeps mounted transcript rows bounded during interaction", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const renderStart = panelSource.indexOf("    renderWindow()");
    const renderEnd = panelSource.indexOf("    getHistoryRenderRange(chunkCount)", renderStart);
    const scrollStart = panelSource.indexOf("    handleHistoryWindowScroll()");
    const scrollEnd = panelSource.indexOf("    trimMountedRowsForInteraction(patch)", scrollStart);
    const settingsStart = panelSource.indexOf("    updateSettings(patch)");
    const settingsEnd = panelSource.indexOf("    shouldPreservePanelPlacement(patch)", settingsStart);
    assert.ok(panelSource.includes("HISTORY_RENDER_WINDOW = 220"));
    assert.ok(panelSource.includes("HISTORY_RENDER_STEP = 110"));
    assert.ok(renderStart >= 0);
    assert.ok(renderEnd > renderStart);
    assert.ok(scrollStart >= 0);
    assert.ok(scrollEnd > scrollStart);
    assert.ok(settingsStart >= 0);
    assert.ok(settingsEnd > settingsStart);
    const renderBody = panelSource.slice(renderStart, renderEnd);
    const scrollBody = panelSource.slice(scrollStart, scrollEnd);
    const settingsBody = panelSource.slice(settingsStart, settingsEnd);
    assert.ok(renderBody.includes("const range = this.getHistoryRenderRange(chunkCount);"));
    assert.ok(renderBody.includes("index <= end"));
    assert.ok(!renderBody.includes("const start = 0;"));
    assert.ok(!renderBody.includes("const end = chunkCount - 1;"));
    assert.ok(scrollBody.includes("this.setHistoryRenderStart(this.currentWindowStart - HISTORY_RENDER_STEP)"));
    assert.ok(scrollBody.includes("this.setHistoryRenderStart(this.currentWindowStart + HISTORY_RENDER_STEP)"));
    assert.ok(settingsBody.includes("this.trimMountedRowsForInteraction(patch);"));
  });

  await runCase("panel scroll containers do not chain wheel scroll into the YouTube page", () => {
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    const viewportStart = css.indexOf(".dc-list-viewport {");
    const viewportEnd = css.indexOf(".dc-list-viewport::-webkit-scrollbar", viewportStart);
    const futureStart = css.indexOf(".dc-future-list {");
    const futureEnd = css.indexOf(".dc-future-list::-webkit-scrollbar", futureStart);
    assert.ok(viewportStart >= 0);
    assert.ok(viewportEnd > viewportStart);
    assert.ok(futureStart >= 0);
    assert.ok(futureEnd > futureStart);
    assert.ok(css.slice(viewportStart, viewportEnd).includes("overscroll-behavior: contain;"));
    assert.ok(css.slice(futureStart, futureEnd).includes("overscroll-behavior: contain;"));
  });

  await runCase("panel reset preserves the selected theme", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const resetStart = panelSource.indexOf("resetPanelDefaults() {");
    const resetEnd = panelSource.indexOf("applyFuturePreviewHeight()", resetStart);
    assert.ok(resetStart >= 0);
    assert.ok(resetEnd > resetStart);
    const resetBody = panelSource.slice(resetStart, resetEnd);
    assert.ok(!resetBody.includes("panelOpacity"));
    assert.ok(!resetBody.includes("fadeTowardVideoCenter"));
    assert.ok(!resetBody.includes("futurePreviewEnabled"));
    assert.ok(!resetBody.includes("caseFixEnabled"));
    assert.ok(resetBody.includes("panelPosition: null"));
    assert.ok(!resetBody.includes("themeName"));
    assert.ok(!resetBody.includes("customThemeColor"));
  });

  await runCase("panel header includes themed brand mark without red asset dependency", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes("dc-brand-mark"));
    assert.ok(panelSource.includes("dc-brand-play"));
    assert.ok(panelSource.includes("dc-brand-bubble"));
    assert.ok(css.includes(".dc-brand-mark"));
    assert.ok(css.includes("rgba(var(--dc-accent-rgb)"));
    assert.ok(!css.includes("#ff0000"));
    assert.ok(!css.includes("#f00"));
  });

  await runCase("reading glow cannot persist without an active timing range", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    assert.ok(panelSource.includes("lastGlowWordEnd"));
    assert.ok(panelSource.includes("this.renderChunkText(textElement, chunk, Boolean(range))"));
    assert.ok(panelSource.includes("this.lastGlowWordEnd = nextGlowWordEnd"));
  });

  await runCase("history reading mode treats upward scroll as explicit reading intent", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    assert.ok(panelSource.includes("historyReadingMode"));
    assert.ok(panelSource.includes("HISTORY_BOTTOM_EXIT_PX = 36"));
    assert.ok(panelSource.includes("enterHistoryReadingMode(\"scroll-up\")"));
    assert.ok(panelSource.includes("getScrollAnchorSnapshot"));
    assert.ok(panelSource.includes("preserveScrollAnchorDuringModeChange"));
    assert.ok(panelSource.includes("restoreScrollAnchorSnapshot"));
    assert.ok(panelSource.includes("preserveScrollBottomDuringModeChange"));
    assert.ok(panelSource.includes("restoreScrollBottomPosition"));
    assert.ok(panelSource.includes("this.scrollAnchorRafId"));
    assert.ok(panelSource.includes("exitHistoryReadingMode(\"current\")"));
    assert.ok(panelSource.includes("exitHistoryReadingMode(\"latest\")"));
    assert.ok(panelSource.includes("this.historyReadingMode && atAbsoluteLatest && nextBottomDistance <= HISTORY_BOTTOM_EXIT_PX"));
    assert.ok(panelSource.includes("!this.historyReadingMode && this.isNearBottom(2.6)"));
    assert.ok(panelSource.includes("!this.historyReadingMode && (this.stickToBottom || this.isNearBottom(2.6))"));
    assert.ok(panelSource.includes("this.historyReadingMode && !options.exitHistoryMode"));
  });

  await runCase("caption hierarchy separates past current and history reading modes", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(css.includes(".dc-panel:not(.is-reading-history) .dc-chunk:not(.is-current):not(.dc-chunk-future)"));
    assert.ok(css.includes(".dc-panel.is-reading-history .dc-chunk:not(.is-current):not(.dc-chunk-future)"));
    assert.ok(css.includes(".dc-chunk:not(.is-current):not(.dc-chunk-future) .dc-chunk-text"));
    assert.ok(css.includes(".dc-chunk.is-current .dc-chunk-text"));
    assert.ok(css.includes("font-size: calc(12.2px * var(--dc-text-scale));"));
    assert.ok(css.includes("line-height: 1.32;"));
    assert.ok(css.includes("font-size: calc(13px * var(--dc-text-scale));"));
    assert.ok(css.includes("line-height: 1.38;"));
    assert.ok(css.includes("font-size: calc(14px * var(--dc-text-scale));"));
    assert.ok(css.includes("line-height: 1.48;"));
    assert.ok(css.includes("font-size 180ms ease"));
    assert.ok(css.includes("line-height 180ms ease"));
    assert.ok(css.includes("text-shadow: 0 0 9px rgba(var(--dc-accent-rgb), 0.13);"));
    assert.ok(panelSource.includes("activeArrivalIndex"));
    assert.ok(panelSource.includes("playActiveArrivalFeedback"));
    assert.ok(panelSource.includes('item.classList.add("is-arriving")'));
    assert.ok(css.includes(".dc-chunk.is-current.is-arriving"));
    assert.ok(css.includes("@keyframes dc-active-arrival"));
    assert.ok(css.includes("translateX(3px) scale(1.012)"));
    assert.ok(css.includes(".dc-chunk.is-current.is-arriving .dc-chunk-text"));
  });

  await runCase("panel exposes basic accessibility labels and reduced-motion CSS", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes('aria-label", "MMO dialogue captions panel"'));
    assert.ok(panelSource.includes('aria-live", "polite"'));
    assert.ok(panelSource.includes('title.textContent = "YTMMOCC"'));
    assert.ok(panelSource.includes('aria-label", "Panel theme"'));
    assert.ok(panelSource.includes('aria-label", "Custom theme color"'));
    assert.ok(panelSource.includes('opacityWrap.textContent = "Opacity"'));
    assert.ok(panelSource.includes('jumpLabel.textContent = "Jump to"'));
    assert.ok(panelSource.includes('this.jumpCurrentButton.textContent = "Current"'));
    assert.ok(panelSource.includes('this.jumpLatestButton.textContent = "Latest"'));
    assert.ok(panelSource.includes('this.helpButton.textContent = "?"'));
    assert.ok(panelSource.includes('aria-label", "Open quick guide"'));
    assert.ok(panelSource.includes('aria-haspopup", "dialog"'));
    assert.ok(panelSource.includes("HELP_POPOVER_ID"));
    assert.ok(panelSource.includes("this.helpPopover.id = this.helpPopoverId"));
    assert.ok(panelSource.includes("#\" + this.helpPopoverId"));
    assert.ok(panelSource.includes('helpTitle.textContent = "Quick Guide"'));
    assert.ok(panelSource.includes('"Click any bubble to seek."'));
    assert.ok(panelSource.includes('"Current returns to the active caption."'));
    assert.ok(panelSource.includes('"Latest jumps to the newest reached caption."'));
    assert.ok(panelSource.includes('"Next previews upcoming captions."'));
    assert.ok(panelSource.includes('"Case Fix softens all-caps captions."'));
    assert.ok(panelSource.includes('"Use the color picker, opacity, and text controls to tune readability."'));
    assert.ok(panelSource.includes('"Presets start as Default, Music, and Podcast loadouts; the lower Save area captures one."'));
    assert.ok(panelSource.includes('"Lock keeps the workspace across videos."'));
    assert.ok(panelSource.includes('"Reset restores the panel workspace shape."'));
    assert.ok(panelSource.includes('"Drag the header to move; drag edges or corners to resize."'));
    assert.ok(panelSource.includes("toggleHelpPopover"));
    assert.ok(panelSource.includes("updateHelpPopoverPosition"));
    assert.ok(panelSource.includes('this.addListener(document, "keydown", onColorPickerEscape);'));
    assert.ok(panelSource.includes("this.closeHelpPopover();"));
    assert.ok(panelSource.includes("jumpToLatestCaption"));
    assert.ok(panelSource.includes("seekLeadSeconds: 0"));
    assert.ok(panelSource.includes("dc-theme-select"));
    assert.ok(panelSource.includes("dc-color-popover"));
    assert.ok(panelSource.includes("dc-rainbow-toggle"));
    assert.ok(panelSource.includes("pickColorFromWheel"));
    assert.ok(panelSource.includes("toggleRainbowThemeMode"));
    assert.ok(panelSource.includes("RAINBOW_THEME_CYCLE_MS = 15000"));
    assert.ok(panelSource.includes("RAINBOW_THEME_FRAME_MS = 33"));
    assert.ok(panelSource.includes("RAINBOW_THEME_SATURATION = 0.84"));
    assert.ok(panelSource.includes("rainbowThemeRestoreSnapshot"));
    assert.ok(panelSource.includes("Math.atan2(dx, -dy)"));
    assert.ok(panelSource.includes("Math.sin(radians)"));
    assert.ok(panelSource.includes("50 - Math.cos(radians)"));
    assert.ok(panelSource.includes("document.body.append(this.colorPickerPopover)"));
    assert.ok(!panelSource.includes('type = "color"'));
    assert.ok(panelSource.includes("getPersistenceSnapshot()"));
    assert.ok(!panelSource.includes('opacityWrap.textContent = "Blend"'));
    assert.ok(!css.includes("::-webkit-color-swatch"));
    assert.ok(css.includes("position: fixed;"));
    assert.ok(css.includes("z-index: 2147483646"));
    assert.ok(css.includes(".dc-color-wheel"));
    assert.ok(css.includes(".dc-rainbow-toggle"));
    assert.ok(css.includes(".dc-help-popover"));
    assert.ok(css.includes(".dc-btn-help"));
    const controlsStart = css.indexOf("\n.dc-controls {");
    const controlsEnd = css.indexOf(".dc-controls *", controlsStart);
    assert.ok(controlsStart >= 0);
    assert.ok(controlsEnd > controlsStart);
    assert.ok(!css.slice(controlsStart, controlsEnd).includes("overflow: hidden;"));
    assert.ok(css.includes("flex-wrap: wrap"));
    assert.ok(css.includes("@media (prefers-reduced-motion: reduce)"));
  });

  await runCase("README does not imply global keyboard shortcuts or Android targeting", () => {
    const readme = fs.readFileSync(path.join(ROOT_DIR, "README.md"), "utf8");
    assert.ok(readme.includes("Hover the panel and press `Space`"));
    assert.ok(readme.includes("desktop Chrome and desktop Firefox only"));
    assert.ok(readme.includes("Timeline Scrub mode remains experimental and is hidden from the normal release UI."));
    assert.ok(!readme.includes("Optional Timeline Scrub mode turns"));
    assert.ok(!readme.includes("gecko_android"));
  });

  await runCase("release has no dormant monetization or ad-network scaffolding", () => {
    const files = [
      "README.md",
      "PRIVACY.md",
      "manifest.json",
      "manifest.chrome.json",
      "manifest.firefox.json",
      "src/settings-store.js",
      "src/content-script.js"
    ];
    for (const fileName of files) {
      const source = fs.readFileSync(path.join(ROOT_DIR, fileName), "utf8");
      assert.ok(!source.includes("feature-flags"), fileName);
      assert.ok(!source.includes("premium"), fileName);
      assert.ok(!source.includes("featureOverrides"), fileName);
      assert.ok(!source.includes("globalKeyboardEnabled"), fileName);
    }
    assert.equal(fs.existsSync(path.join(ROOT_DIR, "src", "feature-flags.js")), false);
  });

  await runCase("release stores only visible local panel preferences", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "settings-store.js"), "utf8");
    assert.ok(!source.includes("chunkSize"));
    assert.ok(!source.includes("keyboardStepSeconds"));
    assert.ok(!source.includes("autoScroll"));
    assert.ok(source.includes("futurePreviewHeight"));
    assert.ok(source.includes("futurePreviewEnabled"));
    assert.ok(source.includes("caseFixEnabled"));
    assert.ok(source.includes("fadeTowardVideoCenter"));
    assert.ok(source.includes("layoutLocked"));
    assert.ok(!source.includes("rainbowThemeEnabled"));
    assert.ok(source.includes("workspacePresets"));
    assert.ok(source.includes("DEFAULT_WORKSPACE_PRESETS"));
    assert.ok(source.includes("activeWorkspacePreset"));
    assert.ok(source.includes("workspacePresetBaseline"));
    assert.ok(source.includes("toStoredSettings"));
    assert.ok(source.includes("timelineModeEnabled"));
    const privacy = fs.readFileSync(path.join(ROOT_DIR, "PRIVACY.md"), "utf8");
    assert.ok(!privacy.includes("chunk size"));
    assert.ok(!privacy.includes("keyboard step"));
    assert.ok(!privacy.includes("auto-scroll"));
    assert.ok(privacy.includes("panel theme preset and custom theme color"));
    assert.ok(privacy.includes("opacity"));
    assert.ok(privacy.includes("Fade"));
    assert.ok(privacy.includes("Case Fix"));
    assert.ok(privacy.includes("Layout Lock"));
    assert.ok(privacy.includes("Fade setting"));
    assert.ok(privacy.includes("workspace preset snapshots"));
  });

  await runCase("workspace model is documented without pinned defaults implementation", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    const architecture = fs.readFileSync(path.join(ROOT_DIR, "ARCHITECTURE.md"), "utf8");
    const readme = fs.readFileSync(path.join(ROOT_DIR, "README.md"), "utf8");
    const qa = fs.readFileSync(path.join(ROOT_DIR, "QA_CHECKLIST.md"), "utf8");
    assert.ok(panelSource.includes("dc-preset-rail"));
    assert.ok(panelSource.includes("toggleWorkspacePreset"));
    assert.ok(panelSource.includes("captureWorkspacePreset"));
    assert.ok(panelSource.includes("workspacePresetBaseline"));
    assert.ok(css.includes(".dc-preset-pill"));
    assert.ok(css.includes("grid-template-rows: 2fr 1fr"));
    assert.ok(architecture.includes("## Workspace / Preferences Model"));
    assert.ok(architecture.includes("Layout Lock off: each video starts from the default panel workspace."));
    assert.ok(architecture.includes("Layout Lock on: the same workspace follows the user across YouTube videos."));
    assert.ok(architecture.includes("Workspace presets: three seeded local snapshot slots act as temporary loadouts"));
    assert.ok(architecture.includes("It does not store video identity, transcript content, current timestamp, active bubble, Lock state"));
    assert.ok(architecture.includes("Reset: returns the panel workspace shape to defaults"));
    assert.ok(architecture.includes("Pinned defaults are deferred."));
    assert.ok(readme.includes("Three seeded local workspace preset slots can save and apply temporary panel layout/readability snapshots"));
    assert.ok(readme.includes("Reset restores the current workspace shape to defaults"));
    assert.ok(readme.includes("The quick guide in the panel header summarizes"));
    assert.ok(qa.includes("Capture a workspace preset after moving/resizing the panel"));
    assert.ok(qa.includes("Confirm no pinned-default UI or second persistence layer is present."));
  });

  await runCase("generic video experiment is source-only and not in release manifests", () => {
    const source = fs.readFileSync(path.join(ROOT_DIR, "src", "universal-captions.js"), "utf8");
    assert.ok(source.includes("HTMLVideoElement"));
    assert.ok(source.includes("TextTrack"));
    assert.ok(source.includes("GenericTextTrackAdapter"));
    assert.ok(!source.includes("getUserMedia"));
    assert.ok(!source.includes("MediaRecorder"));
    assert.ok(!source.includes("fetch("));
    for (const fileName of manifests) {
      const manifest = readJson(fileName);
      assert.ok(!JSON.stringify(manifest).includes("universal-captions.js"), fileName);
    }
  });

  await runCase("timeline scrub mode reuses panel chunks and stays optional", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const scrubSource = fs.readFileSync(path.join(ROOT_DIR, "src", "timeline-scrub.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes("setTimelineData"));
    assert.ok(panelSource.includes("dc-timeline-lens"));
    assert.ok(panelSource.includes("TIMELINE_MODE_EXPERIMENT_ENABLED = false"));
    assert.ok(panelSource.includes("timelineFeatureEnabled"));
    assert.ok(panelSource.includes("timelineModeEnabled"));
    assert.ok(panelSource.includes("handleTimelineClick"));
    assert.ok(panelSource.includes('this.body.style.display = timelineActive ? "none" : "flex"'));
    assert.ok(panelSource.includes("this.body.hidden = timelineActive"));
    assert.ok(panelSource.includes("timelineDataKey"));
    assert.ok(panelSource.includes("this.timelineHoverIndex = -1;"));
    assert.ok(panelSource.includes("this.timelineHoverTime = Number.NaN;"));
    assert.ok(panelSource.includes("const lensTime = Number.isFinite(this.timelineHoverTime)"));
    assert.ok(panelSource.includes("dc-timeline-lens-text dc-chunk-text"));
    assert.ok(panelSource.includes("this.renderChunkText(text, focusChunk, true, clampedLensTime)"));
    assert.ok(panelSource.includes('this.timelineLayer.style.setProperty("--dc-text-scale"'));
    assert.ok(panelSource.includes('this.timelineLayer.style.setProperty("--dc-accent"'));
    assert.ok(panelSource.includes('this.timelineTooltip.classList.add("is-visible")'));
    assert.ok(panelSource.includes('this.timelineTooltip.classList.toggle("is-hover"'));
    assert.ok(panelSource.includes("Math.pow(blend, 0.72)"));
    assert.ok(panelSource.includes("const fadeX = Math.max(0, Math.min(100"));
    assert.ok(panelSource.includes("const centerAlpha = enabled ?"));
    assert.ok(panelSource.includes('this.root.style.setProperty("--dc-edge-mask-alpha"'));
    assert.ok(panelSource.includes('setAlpha("--dc-panel-alpha-outer", 0.16 + eased * 0.84)'));
    assert.ok(panelSource.includes('setAlpha("--dc-card-alpha", 0.2 + eased * 0.8)'));
    assert.ok(scrubSource.includes("hoverXToTime"));
    assert.ok(scrubSource.includes("findChunkIndexAtTime"));
    assert.ok(css.includes(".dc-timeline-layer"));
    assert.ok(css.includes(".dc-timeline-lens"));
    assert.equal(css.includes(".dc-timeline-lens::after"), false);
    assert.ok(css.includes(".dc-timeline-lens-time"));
    assert.ok(css.includes(".dc-timeline-lens-text"));
    assert.ok(css.includes("background: transparent;"));
    assert.ok(css.includes("radial-gradient("));
    assert.ok(css.includes('font-family: "Trebuchet MS", "Segoe UI", sans-serif;'));
    assert.ok(css.includes("font-size: calc(15px * var(--dc-text-scale, 1.2))"));
    assert.ok(css.includes("width: min(860px, 82vw)"));
    assert.ok(css.includes(".dc-timeline-lens.is-hover"));
    assert.ok(css.includes(".dc-panel.is-timeline-scrub .dc-controls"));
    assert.ok(!css.includes(".dc-rail-popover"));
    assert.ok(css.includes(".dc-panel-open .ytp-caption-window-rollup"));
    assert.ok(css.includes(".dc-panel-open .ytp-caption-segment"));
  });

  await runCase("video-anchored panel mounts inside the player instead of floating over comments", () => {
    const panelSource = fs.readFileSync(path.join(ROOT_DIR, "src", "ui-panel.js"), "utf8");
    const css = fs.readFileSync(path.join(ROOT_DIR, "styles", "panel.css"), "utf8");
    assert.ok(panelSource.includes("resolveMountElement()"));
    assert.ok(panelSource.includes('(this.mountElement || document.body).append(this.root)'));
    assert.ok(panelSource.includes("getElementLocalRect"));
    assert.ok(panelSource.includes("localToPlayerPanelPosition"));
    assert.ok(panelSource.includes("isAnchorUsablyVisible()"));
    assert.ok(panelSource.includes("is-anchor-offscreen"));
    assert.ok(css.includes("dc-player-host"));
    assert.ok(css.includes("position: absolute;"));
    assert.ok(css.includes(".dc-panel.is-anchor-offscreen"));
    assert.ok(css.includes(".dc-launcher.is-anchor-offscreen"));
  });
};
