@echo off
setlocal
set "MANIFEST=%~dp0firefox-temporary\manifest.json"
echo Dialogue Captions - Firefox temporary local install
echo.
echo This copied the Firefox manifest path to your clipboard:
echo %MANIFEST%
echo.
echo Steps:
echo  1. Click This Firefox if needed.
echo  2. Click Load Temporary Add-on.
echo  3. Paste/select the manifest.json path above.
echo  4. Open a YouTube video and click the Captions pill in the video frame.
echo.
echo Note: Standard Firefox requires signed add-ons for normal permanent install.
echo This temporary install is for testing and disappears when Firefox is restarted.
echo.
echo Opening about:debugging now...
echo %MANIFEST%| clip
where firefox.exe >nul 2>nul
if %ERRORLEVEL%==0 (
  start "" firefox.exe "about:debugging#/runtime/this-firefox"
) else (
  start "" "about:debugging#/runtime/this-firefox"
)
pause
