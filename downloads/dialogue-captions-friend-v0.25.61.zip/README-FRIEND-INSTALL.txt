﻿Dialogue Captions v0.25.61 - Friend Test Bundle

What this is:
A local test build of Dialogue Captions, a YouTube extension that turns captions into an MMO-style chat panel.

What to send:
Send this whole ZIP file:
dialogue-captions-friend-v0.25.61.zip

Chrome install:
1. Extract the ZIP somewhere simple, like Desktop.
2. Double-click install-chrome.bat.
3. Chrome opens chrome://extensions.
4. Enable Developer mode.
5. Click Load unpacked.
6. Select the chrome-unpacked folder.
7. Open a YouTube video and click the small Captions pill inside the video.

Firefox install:
1. Extract the ZIP somewhere simple, like Desktop.
2. Double-click install-firefox.bat.
3. Firefox opens about:debugging#/runtime/this-firefox.
4. Click Load Temporary Add-on.
5. Select firefox-temporary\manifest.json.
6. Open a YouTube video and click the small Captions pill inside the video.

Important Firefox note:
Normal Firefox will not permanently install unsigned extension files. Temporary loading from about:debugging works for testing. Permanent public sharing requires signing through Mozilla Add-ons.

Usage notes:
- The extension only runs on YouTube watch pages.
- It starts as a small Captions pill in the video frame.
- Click the pill to open the dialogue panel.
- It may turn YouTube captions on while open so it can read caption text.
- Collapse the panel when done.

If it does not appear:
- Refresh the YouTube video page.
- Make sure the extension is enabled.
- Try a video that has captions available.
