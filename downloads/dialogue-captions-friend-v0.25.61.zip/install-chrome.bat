@echo off
setlocal
set "EXT_DIR=%~dp0chrome-unpacked"
echo Dialogue Captions - Chrome local install
echo.
echo This copied the extension folder path to your clipboard:
echo %EXT_DIR%
echo.
echo Steps:
echo  1. Turn on Developer mode in the top-right.
echo  2. Click Load unpacked.
echo  3. Paste/select the folder path above.
echo  4. Open a YouTube video and click the Captions pill in the video frame.
echo.
echo Opening chrome://extensions now...
echo %EXT_DIR%| clip
where chrome.exe >nul 2>nul
if %ERRORLEVEL%==0 (
  start "" chrome.exe "chrome://extensions/"
) else (
  start "" "chrome://extensions/"
)
pause
